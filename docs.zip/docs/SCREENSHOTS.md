# Screenshots to capture

Take these three images and save them in `docs/` with the exact filenames below.
They are referenced in the README and serve as visual proof for both offline and live modes.

---

## 1. `docs/dashboard-overview.png`  (offline — highest impact)

**What to show**
- Streamlit triage UI at http://localhost:8501
- Summary metrics visible (Sessions / Alert / Review / Dismissed)
- At least one **Alert** session expanded (reasons + commands visible)
- At least one **Review** session visible (ideally with the promote/dismiss buttons)

**How**
```bash
source .venv/bin/activate          # if using a venv
python3 samples/generate_samples.py
streamlit run src/dashboard.py
```
Open the Alert tab, expand the top session, also open or show the Review queue, then screenshot the browser window.

---

## 2. `docs/pipeline-cli.png`  (offline — CLI proof)

**What to show**
- Terminal output of the pipeline
- Clear ALERT / REVIEW / dismiss counts
- At least two scored sessions with plain-English reasons

**How**
```bash
python3 samples/generate_samples.py
python3 src/pipeline.py --logfile samples/cowrie.json -v
```
Screenshot the terminal. Use a dark terminal theme and a readable font size.

---

## 3. `docs/wazuh-dashboard.png`  (live stack)

**What to show**
- Wazuh dashboard (https://localhost:5601)
- Cowrie-related alerts visible (successful login, brute-force, and/or command execution)
- Ideally show rule level, src_ip, and description

**How**
```bash
./scripts/setup.sh
docker compose up -d
./scripts/generate_traffic.sh
# also manually: ssh -p 2222 root@localhost  (try a few passwords)
```
Log in to https://localhost:5601 (admin / SecretPassword).  
Go to Threat Hunting / Security Events (or the alerts view), filter for Cowrie or the custom rule IDs (100101–100110), and capture a clean screenshot of firing alerts.

---

## Tips

- Crop tightly — remove unnecessary browser chrome if it distracts.
- Prefer one clear window over multiple tiny panels.
- Dark theme looks more professional for both Streamlit and the terminal.
- After capturing, confirm the images render on GitHub by checking the README preview.
